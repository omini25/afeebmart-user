// actions.js
export const LOGOUT = 'LOGOUT';

export const logout = () => ({
    type: LOGOUT
});