export const ADD_TO_CART = 'ADD_TO_CART';

export const addToCart = (product) => ({
    type: ADD_TO_CART,
    payload: product,
});

export const removeFromCart = (product) => (dispatch, getState) => {
    dispatch({
        type: 'REMOVE_FROM_CART',
        payload: product,
    });

    localStorage.setItem('cart', JSON.stringify(getState().cart));
};

export const loadCart = (data) => (dispatch) => {
    dispatch({
        type: 'LOAD_CART',
        payload: data
    });
};